#!/usr/bin/env sh
set -e

CONFIG=/data/options.json

export FRONIUS_HOST="$(jq -r '.fronius_host' "$CONFIG")"
export FRONIUS_DEVICE_ID="$(jq -r '.fronius_device_id' "$CONFIG")"
export POLL_INTERVAL="$(jq -r '.poll_interval' "$CONFIG")"
export LISTEN_PORT=5061

echo "[fronius-relay] starting: host=$FRONIUS_HOST device=$FRONIUS_DEVICE_ID poll=${POLL_INTERVAL}s"
exec python3 /app.py
