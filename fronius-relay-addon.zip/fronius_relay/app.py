"""Fronius MPPT relay.

Polls a Fronius Primo inverter on the LAN every 30s and exposes per-MPPT
voltage / current / watts as JSON for HA to consume.

Reads config from env:
  FRONIUS_HOST  default "192.168.50.181"
  FRONIUS_DEVICE_ID  default "1"
  POLL_INTERVAL  default 30 (seconds)

Endpoints:
  GET /            quick health (text)
  GET /healthz     healthcheck
  GET /fronius/mppt  full JSON (cache, polled in background)
  GET /fronius/mppt/string1  -> "<W>|<V>|<A>"  (compact, for scrape regex)
  GET /fronius/mppt/string2  -> "<W>|<V>|<A>"
"""
import os, json, threading, time
import urllib.request
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

HOST = os.environ.get("FRONIUS_HOST", "192.168.50.181")
DEVICE_ID = os.environ.get("FRONIUS_DEVICE_ID", "1")
POLL = int(os.environ.get("POLL_INTERVAL", "30"))
LISTEN_PORT = int(os.environ.get("LISTEN_PORT", "5061"))
URL_3P = f"http://{HOST}/solar_api/v1/GetInverterRealtimeData.cgi?Scope=Device&DeviceId={DEVICE_ID}&DataCollection=3PInverterData"
URL_COMMON = f"http://{HOST}/solar_api/v1/GetInverterRealtimeData.cgi?Scope=Device&DeviceId={DEVICE_ID}&DataCollection=CommonInverterData"

# Mutable cache shared between the poller and HTTP handlers.
state = {
    "ts": 0,
    "fetched_at": None,
    "ok": False,
    "raw_3p": None,
    "raw_common": None,
    "string1": {"voltage_v": None, "current_a": None, "watts": None},
    "string2": {"voltage_v": None, "current_a": None, "watts": None},
    "ac_watts": None,
    "error": None,
}
state_lock = threading.Lock()


def _safe_value(d, key):
    """Fronius returns {"Values":{"1":{...}}, "Unit":"V"}. Pull values dict if present."""
    if not isinstance(d, dict):
        return {}
    return (d.get(key) or {}).get("Values") or {}


def fetch_once():
    raw3p = raw_common = None
    err = None
    try:
        with urllib.request.urlopen(URL_COMMON, timeout=5) as r:
            raw_common = json.loads(r.read().decode("utf-8"))
    except Exception as e:
        err = f"common: {e}"
    try:
        with urllib.request.urlopen(URL_3P, timeout=5) as r:
            raw3p = json.loads(r.read().decode("utf-8"))
    except Exception as e:
        err = (err + " | " if err else "") + f"3p: {e}"

    s1_v = s2_v = s1_a = s2_a = None
    ac_w = None

    # 3PInverterData carries per-MPPT values. Field names per Fronius Solar API v1:
    #   UDC, IDC = MPPT1 (DC voltage/current of string 1)
    #   UDC_2, IDC_2 = MPPT2 (string 2)
    if isinstance(raw3p, dict):
        body = (raw3p.get("Body") or {}).get("Data") or {}
        # Some firmwares bury values under {key: {"Value": x, "Unit": y}}
        def get(k):
            v = body.get(k)
            if isinstance(v, dict):
                return v.get("Value")
            return v
        s1_v = get("UDC")
        s1_a = get("IDC")
        s2_v = get("UDC_2")
        s2_a = get("IDC_2")

    # CommonInverterData: aggregate AC power
    if isinstance(raw_common, dict):
        body = (raw_common.get("Body") or {}).get("Data") or {}
        pac = body.get("PAC")
        if isinstance(pac, dict):
            ac_w = pac.get("Value")

    def watts(v, a):
        if v is None or a is None:
            return None
        try:
            return round(float(v) * float(a), 1)
        except Exception:
            return None

    with state_lock:
        state["ts"] = time.time()
        state["fetched_at"] = time.strftime("%Y-%m-%dT%H:%M:%S%z", time.localtime())
        state["raw_3p"] = raw3p
        state["raw_common"] = raw_common
        state["string1"] = {"voltage_v": s1_v, "current_a": s1_a, "watts": watts(s1_v, s1_a)}
        state["string2"] = {"voltage_v": s2_v, "current_a": s2_a, "watts": watts(s2_v, s2_a)}
        state["ac_watts"] = ac_w
        state["ok"] = err is None
        state["error"] = err


def poller():
    while True:
        try:
            fetch_once()
        except Exception as e:
            with state_lock:
                state["error"] = repr(e)
                state["ok"] = False
        time.sleep(POLL)


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a, **kw):
        return  # quiet

    def _send(self, code, body, ctype="application/json"):
        b = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(b)))
        self.end_headers()
        self.wfile.write(b)

    def do_GET(self):
        with state_lock:
            snap = dict(state)
            s1, s2 = snap["string1"], snap["string2"]
        if self.path in ("/", "/healthz"):
            return self._send(200, "ok\n", "text/plain")
        if self.path == "/fronius/mppt":
            return self._send(200, json.dumps(snap, default=str))
        if self.path == "/fronius/mppt/string1":
            payload = f"{s1.get('watts')}|{s1.get('voltage_v')}|{s1.get('current_a')}\n"
            return self._send(200, payload, "text/plain")
        if self.path == "/fronius/mppt/string2":
            payload = f"{s2.get('watts')}|{s2.get('voltage_v')}|{s2.get('current_a')}\n"
            return self._send(200, payload, "text/plain")
        self._send(404, "not found\n", "text/plain")


def main():
    threading.Thread(target=poller, daemon=True).start()
    # Initial blocking fetch so the first GET has data
    fetch_once()
    srv = ThreadingHTTPServer(("0.0.0.0", LISTEN_PORT), Handler)
    print(f"fronius-relay on :{LISTEN_PORT}, polling {HOST} every {POLL}s")
    srv.serve_forever()


if __name__ == "__main__":
    main()
