# Fronius MPPT Relay — Local HA Add-on

Polls a Fronius Primo inverter on the LAN every poll_interval seconds and
exposes per-MPPT (string 1 / string 2) DC voltage, current, and watts as JSON
for HA scrape sensors to consume.

## Endpoints
- GET /healthz
- GET /fronius/mppt
- GET /fronius/mppt/string1
- GET /fronius/mppt/string2

## Configuration
- fronius_host (default 192.168.50.181)
- fronius_device_id (default "1")
- poll_interval (default 30, range 5..3600)

## Install
1. Copy the fronius_relay/ folder into /addons/ on your HAOS host
   (Samba share \\<HA-IP>\addons, File Editor, or Terminal SSH).
2. HA UI: Settings -> Add-ons -> Add-on Store -> menu -> Reload (or wait).
3. Scroll to "Local Add-ons" -> "Fronius MPPT Relay" -> Install -> Start.
4. Check the Log tab for "[fronius-relay] starting: ...".

## Verifying
curl http://<HA-VM-LAN-IP>:5061/fronius/mppt
